#include <stdlib.h>

int get_callinfo(char *fname, size_t fnlen, unsigned long long *ofs)
{
  return -1;
}
